
#ifndef NTL_version__H
#define NTL_version__H

#define NTL_VERSION "11.4.3"

#define NTL_MAJOR_VERSION  (11)
#define NTL_MINOR_VERSION  (4)
#define NTL_REVISION       (3)

#endif

