
#ifndef NTL_vec_ulong__H
#define NTL_vec_ulong__H

#include <NTL/vector.h>

NTL_OPEN_NNS

typedef Vec<unsigned long> vec_ulong;

NTL_CLOSE_NNS

#endif
